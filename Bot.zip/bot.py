# bot.py
import asyncio
import os
import sys

from telegram.ext import ApplicationBuilder
from features.link_cmd import register_handlers
from features.wishlist_cmd import register_wishlist
from features.icon_cmd import register_icon
from features.convert_cmd import register_convert

BOT_TOKEN = os.getenv("TELEGRAM_TOKEN")


async def main():
    if not BOT_TOKEN:
        print("❌ TELEGRAM_TOKEN tidak ditemukan di Secret!")
        sys.exit(1)

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # registrasi fitur
    register_handlers(app)
    register_wishlist(app)
    register_icon(app)
    register_convert(app)

    print("🤖 Bot aktif! Siap menerima perintah di Telegram.")

    # run polling (await)
    await app.run_polling()


if __name__ == "__main__":
    # Compatibility with hosted runners that may already run an event loop
    try:
        import nest_asyncio
        nest_asyncio.apply()
        asyncio.get_event_loop().run_until_complete(main())
    except ModuleNotFoundError:
        asyncio.run(main())