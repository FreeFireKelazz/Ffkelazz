import asyncio
import aiohttp
import os
import shutil
import zipfile
import tempfile
import time
from pathlib import Path
from typing import Dict, Any, Optional, List

ASSETSTUDIO_PATH = Path(__file__).resolve().parents[2] / "AssetStudio" / "AssetStudio.CLI.dll"

from telegram import Update
from telegram.ext import (
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# ---------------- CONFIG ----------------
TELEGRAM_MAX_FILE_BYTES = int(os.getenv("TELEGRAM_MAX_FILE_BYTES", str(2 * 1024 * 1024 * 1024)))
DL_CHUNK = 1024 * 1024            # 1 MB chunk
PROGRESS_BAR_LEN = 15
PROGRESS_UPDATE_MIN_SEC = 0.8
DOWNLOAD_RETRIES = 3
DEFAULT_CATEGORIES = [
    "Animator", "AudioClip", "Font", "Mesh", "MonoBehaviour",
    "Shader", "Sprite", "TextAsset", "VideoClip", "Texture2D"
]
# ----------------------------------------

_states: Dict[int, Dict[str, Any]] = {}  # per-chat simple state

# ---------------- helpers ----------------
def human_size(nbytes: int) -> str:
    if nbytes is None:
        return "0B"
    n = float(nbytes)
    if n >= 1024 ** 3:
        return f"{n / (1024 ** 3):.2f} GB"
    if n >= 1024 ** 2:
        return f"{n / (1024 ** 2):.2f} MB"
    if n >= 1024:
        return f"{n / 1024:.2f} KB"
    return f"{n} B"

def build_bar(done: int, total: int, length: int = PROGRESS_BAR_LEN) -> str:
    if total and total > 0:
        percent = int(done / total * 100)
    else:
        percent = 0
    filled = int(length * percent / 100) if total and total > 0 else int(min(length, max(1, done // (1024*1024))))
    filled = min(length, filled)
    bar = "█" * filled + "░" * (length - filled)
    if total and total > 0:
        return f"[{bar}] {percent}% ({human_size(done)}/{human_size(total)})"
    else:
        return f"[{bar}] ({human_size(done)}/?)"

async def edit_progress_safe(msg_obj, text: str):
    try:
        await msg_obj.edit_text(text)
    except Exception:
        pass

def find_categories(root_dir: Path, categories: List[str] = DEFAULT_CATEGORIES) -> Dict[str, Path]:
    found: Dict[str, Path] = {}
    for p in root_dir.rglob("*"):
        if p.is_dir():
            name = p.name
            for cat in categories:
                if name.lower() == cat.lower() and cat not in found:
                    found[cat] = p
    for cat in categories:
        cand = root_dir / cat
        if cand.exists() and cand.is_dir() and cat not in found:
            found[cat] = cand
    return found

# ---------------- download ----------------
async def download_with_progress(url: str, dest: Path, progress_msg, context, chat_id: int) -> bool:
    for attempt in range(1, DOWNLOAD_RETRIES + 1):
        try:
            async with aiohttp.ClientSession() as ses:
                async with ses.get(url, timeout=aiohttp.ClientTimeout(total=None)) as resp:
                    if resp.status != 200:
                        await edit_progress_safe(progress_msg, f"❌ Gagal download (HTTP {resp.status}). Attempt {attempt}/{DOWNLOAD_RETRIES}")
                        await asyncio.sleep(1 + attempt)
                        continue
                    total = int(resp.headers.get("Content-Length") or 0)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    done = 0
                    last_percent = -1
                    last_report_time = time.time() - PROGRESS_UPDATE_MIN_SEC
                    with open(dest, "wb") as f:
                        async for chunk in resp.content.iter_chunked(DL_CHUNK):
                            if not chunk:
                                break
                            f.write(chunk)
                            done += len(chunk)
                            percent = int(done / total * 100) if total > 0 else 0
                            now = time.time()
                            if (percent != last_percent and now - last_report_time >= PROGRESS_UPDATE_MIN_SEC) or (now - last_report_time > 5):
                                bar = build_bar(done, total)
                                await edit_progress_safe(progress_msg, f"📥 Mengunduh APK...\n{bar}")
                                last_percent = percent
                                last_report_time = now
                    bar = build_bar(done, total)
                    await edit_progress_safe(progress_msg, f"📥 Mengunduh APK... Selesai\n{bar}")
                    return True
        except Exception as e:
            await edit_progress_safe(progress_msg, f"⚠️ Error download (try {attempt}/{DOWNLOAD_RETRIES}): {e}")
            await asyncio.sleep(1 + attempt * 2)
            continue
    await edit_progress_safe(progress_msg, "❌ Gagal mendownload APK setelah beberapa percobaan. Cek link atau coba lagi.")
    return False

# ---------------- setelah download ----------------
async def process_after_download(apk_url, apk_path, progress_msg, context, update, out_dir):
    ok = await download_with_progress(apk_url, apk_path, progress_msg, context, update.effective_chat.id)
    if not ok:
        return False

    await edit_progress_safe(progress_msg, "📦 Download selesai! Mengekstrak APK ke folder sementara...")

    if not apk_path.exists():
        await edit_progress_safe(progress_msg, "❌ File APK tidak ditemukan setelah download.")
        return False

    unzip_dir = out_dir / "apk_unzipped"
    unzip_dir.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(apk_path, 'r') as zip_ref:
            zip_ref.extractall(unzip_dir)
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal unzip APK: {e}")
        return False

    if not shutil.which("dotnet"):
        await edit_progress_safe(progress_msg, "❌ .NET runtime tidak ditemukan di environment.")
        return False

    output_asset_dir = out_dir / "assetstudio_out"
    output_asset_dir.mkdir(parents=True, exist_ok=True)

    if not ASSETSTUDIO_PATH.exists():
        await edit_progress_safe(progress_msg, f"❌ AssetStudio not found at: {ASSETSTUDIO_PATH}")
        return False

    input_path = unzip_dir / "assets" / "bin" / "Data"
    if not input_path.exists():
        input_path = unzip_dir / "assets"

    await edit_progress_safe(progress_msg, f"📦 Menjalankan ekstraksi via AssetStudioCLI...\n📁 Input: {input_path}")

    # --- Step 1: Build CABMap ---
    cmd_map = [
        "dotnet", str(ASSETSTUDIO_PATH),
        str(input_path),
        str(output_asset_dir),
        "--map_op", "CABMap",
        "--map_name", "ff_cliCabMap",
        "--game", "CB1",
        "--silent"
    ]

    try:
        proc_map = await asyncio.create_subprocess_exec(
            *cmd_map,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout_map, stderr_map = await asyncio.wait_for(proc_map.communicate(), timeout=900)
    except asyncio.TimeoutError:
        await edit_progress_safe(progress_msg, "⚠️ Build CABMap timeout (15 menit). Dihentikan.")
        return False
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal menjalankan CABMap: {e}")
        return False

    log_map = stdout_map.decode(errors="ignore") + stderr_map.decode(errors="ignore")
    if proc_map.returncode != 0:
        await edit_progress_safe(progress_msg, f"❌ AssetStudioCLI CABMap gagal (exit code {proc_map.returncode}).\n<code>{log_map[:1800]}</code>")
        return False
    await edit_progress_safe(progress_msg, f"🗺️ Build Map selesai.\n<code>{log_map[:1200]}</code>")

    # --- Step 2: Extract Assets (Load) ---
    cmd_extract = [
        "dotnet", str(ASSETSTUDIO_PATH),
        str(input_path),
        str(output_asset_dir),
        "--map_op", "Load",
        "--map_name", "ff_cliCabMap",
        "--game", "CB1",
        "--group_assets_type", "ByType",
        "--silent"
    ]
    for t in DEFAULT_CATEGORIES:
        cmd_extract.extend(["--type", t])

    try:
        proc_extract = await asyncio.create_subprocess_exec(
            *cmd_extract,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout_extract, stderr_extract = await asyncio.wait_for(proc_extract.communicate(), timeout=1800)
    except asyncio.TimeoutError:
        await edit_progress_safe(progress_msg, "⚠️ AssetStudioCLI timeout (30 menit). Dihentikan.")
        return False
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal menjalankan AssetStudioCLI: {e}")
        return False

    log_extract = stdout_extract.decode(errors="ignore") + stderr_extract.decode(errors="ignore")

    # --- Exit code check ---
    if proc_extract.returncode != 0:
        await edit_progress_safe(progress_msg, f"❌ AssetStudioCLI gagal (exit code {proc_extract.returncode}).\n<code>{log_extract[:1800]}</code>")
        return False

    await edit_progress_safe(progress_msg, f"📄 Log AssetStudio (Extract):\n<code>{log_extract[:1500]}</code>")

    # --- Validate output ---
    if not output_asset_dir.exists() or not any(output_asset_dir.iterdir()):
        await edit_progress_safe(progress_msg, "⚠️ AssetStudio selesai tapi tidak menghasilkan file apapun.")
        return False

    total_files = len(list(output_asset_dir.glob('**/*')))
    if total_files < 10:
        await edit_progress_safe(progress_msg, f"⚠️ Hasil ekstraksi sangat sedikit ({total_files} file). Mungkin gagal parsing sebagian.")
    
    # --- Compress & send results ---
    await edit_progress_safe(progress_msg, "🗜️ Mengompres hasil ekstraksi...")
    categories = find_categories(output_asset_dir)
    if not categories:
        categories = {"AllAssets": output_asset_dir}

    for name, folder in categories.items():
        zip_name = f"{name}.zip"
        zip_path = out_dir / zip_name
        try:
            shutil.make_archive(str(zip_path).replace(".zip", ""), "zip", folder)
            await edit_progress_safe(progress_msg, f"📤 Mengirim {zip_name}...")
            with open(zip_path, "rb") as fh:
                await context.bot.send_document(chat_id=update.effective_chat.id, document=fh, filename=zip_name)
        except Exception as e:
            await edit_progress_safe(progress_msg, f"⚠️ Gagal mengirim {zip_name}: {e}")
        finally:
            zip_path.unlink(missing_ok=True)

    await edit_progress_safe(progress_msg, "✅ Semua hasil berhasil dikirim.")
    return True

# ---------------- handlers ----------------
async def cmdextract(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    _states[chat_id] = {"mode": "awaiting_url"}
    await update.message.reply_text("🧩 Kirim link APK yang ingin diekstrak menggunakan AssetStudioCLI.")

async def helpextract(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ Cara pakai:\n\n1️⃣ Ketik /cmdextract\n2️⃣ Kirim link APK (.apk)\n3️⃣ Tunggu proses ekstraksi selesai."
    )

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query:
        await query.answer()
        await query.edit_message_text("Callback belum diimplementasi.")

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state or state.get("mode") != "awaiting_url":
        return

    apk_url = update.message.text.strip()
    if not apk_url.startswith("http"):
        await update.message.reply_text("⚠️ Link tidak valid. Harus berawalan http atau https.")
        return

    progress_msg = await update.message.reply_text("📥 Mulai download dan ekstraksi...")
    work_dir = Path(tempfile.mkdtemp(prefix="coolbot_extract_"))
    apk_path = work_dir / "input.apk"

    await process_after_download(apk_url, apk_path, progress_msg, context, update, work_dir)
    _states.pop(chat_id, None)

# ---------------- register command ----------------
def register_extract(app):
    app.add_handler(CommandHandler("cmdextract", cmdextract))
    app.add_handler(CommandHandler("helpextract", helpextract))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))