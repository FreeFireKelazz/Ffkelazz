# features/wishlist_cmd.py
import asyncio
import aiohttp
import aiofiles
import json
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# ---------------- CONFIG ----------------
API_BASE_ADD = "https://ob50-add-femboy.vercel.app/api/add"
API_BASE_REMOVE = "https://ob50-add-femboy.vercel.app/api/remove"
# Do NOT change ob50 in API_BASE_*

MAX_CONSECUTIVE_ERRORS = 10         # jika 10 error berturut-turut -> skip kategori
MAX_ATTEMPTS_PER_CATEGORY = 2000    # safety upper bound per kategori
REQUEST_DELAY = 0.25                # jeda antar request (detik) untuk mengurangi rate-limit
CATEGORY_ATTEMPT_DISPLAY = 200      # skala progress bar visual
HTTP_TIMEOUT = 30                   # timeout per request (detik)
MAX_PER_ACCOUNT = 70                # maksimal item yang boleh di-wishlist per guest account
MAX_ACCOUNTS = 4                    # maksimal guest accounts yang diminta
# ---------------------------------------

_states: Dict[int, Dict[str, Any]] = {}

# KATEGORI DEFAULT (prefix, display name, pad width)
# Note: pad width 2 or 3 depending kategori; 90710 example uses pad 2 in prior mapping
CATEGORIES_ALL: List[Tuple[str, str, int]] = [
    ("9010", "Banner", 3),
    ("9020", "Headpic", 3),
    ("9030", "Lootbox", 3),
    ("9040", "Backpack", 3),
    ("9050", "Parachute", 3),
    ("9060", "Skateboard", 3),
    ("90710", "Weapon", 2),
    ("9080", "Vehicle", 3),
    ("9090", "Emote", 3),
    ("9100", "Pin", 3),
    ("91100", "Skywing", 2),
    ("9120", "Arrival Animation", 3),
    ("9130", "Music", 3),
    ("9140", "Look Changer", 3),
    ("9180", "Medkit Posture", 3),
    ("9190", "Jump Posture", 3),
    ("9200", "Fall Posture", 3),
    ("9210", "Voice Pack", 3),
    ("9220", "Skill Skin", 3),
    ("9230", "Final Shot", 3),
    ("9095", "Super Emote", 3),
    ("9250", "Battle Card", 3),
    ("7100", "Bundle", 3),
    ("2030", "Top Outfit", 3),
    ("2040", "Bottom Outfit", 3),
    ("2050", "Shoes Outfit", 3),
    ("2110", "Head Outfit", 3),
    ("2140", "Facepaint", 3),
    ("8010", "Token", 3),
    ("92600", "Frame", 2),
]

# Pembagian kategori per akun (sesuai permintaan user)
ACCOUNTS_CATEGORIES: List[List[Tuple[str, str, int]]] = [
    # Akun 1: Bundle, Emote, Arrival Animation, Skywing
    [c for c in CATEGORIES_ALL if c[0] in {"7100", "9090", "9120", "91100"}],
    # Akun 2: Weapon, Music
    [c for c in CATEGORIES_ALL if c[0] in {"90710", "9130"}],
    # Akun 3: Lootbox, Backpack, Parachute, Vehicle, Skyboard
    [c for c in CATEGORIES_ALL if c[0] in {"9030", "9040", "9050", "9080", "9060"}],
    # Akun 4: Banner, Avatar(Headpic), Facepaint
    [c for c in CATEGORIES_ALL if c[0] in {"9010", "9020", "2140"}],
]

# ---------------- helpers ----------------
def title_text(s: str) -> str:
    """Return Title Case for the message: Each Word First Letter Uppercase."""
    if not s:
        return s
    # Use str.title() (it lowercases others) — good for consistent Title Case styling
    return s.title()

def build_bar(done: int, total_scale: int = CATEGORY_ATTEMPT_DISPLAY, length: int = 20) -> str:
    ratio = min(1.0, done / max(1, total_scale))
    filled = int(length * ratio)
    bar = "█" * filled + "░" * (length - filled)
    percent = int(ratio * 100)
    return f"[{bar}] {percent}%"

async def edit_safe(msg_obj, text: str):
    try:
        await msg_obj.edit_text(title_text(text))
    except Exception:
        pass

async def download_document_to_path(file_obj, dest: Path):
    """Download telegram File to dest path (async)."""
    await file_obj.download_to_drive(str(dest))

async def parse_guest_file(path: Path) -> Optional[Tuple[str, str]]:
    """Parse guest file and return (uid, pwd) or None."""
    try:
        async with aiofiles.open(path, "r", encoding="utf-8") as fh:
            raw = await fh.read()
        data = json.loads(raw)
        g = data.get("guest_account_info") or {}
        uid = g.get("com.garena.msdk.guest_uid") or g.get("guest_uid")
        pwd = g.get("com.garena.msdk.guest_password") or g.get("guest_password")
        if uid and pwd:
            return str(uid), str(pwd)
    except Exception:
        return None
    return None

async def call_wishlist_api(session: aiohttp.ClientSession, action: str, item_id: str, uid: str, pwd: str) -> Tuple[bool, str]:
    """
    action: 'add' or 'remove'
    Returns (success_bool, response_snippet)
    """
    if action == "add":
        url = f"{API_BASE_ADD}/{item_id}/sg/{uid}/{pwd}"
    else:
        url = f"{API_BASE_REMOVE}/{item_id}/sg/{uid}/{pwd}"
    try:
        async with session.get(url, timeout=HTTP_TIMEOUT) as resp:
            txt = await resp.text()
            if resp.status == 200:
                return True, txt[:300]
            else:
                return False, f"HTTP {resp.status}"
    except Exception as e:
        return False, str(e)

# ---------------- conversation & flow ----------------
async def cmdwishlist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    _states[chat_id] = {"mode": "await_runmode"}
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("Otomatis", callback_data="wl_mode_auto"),
         InlineKeyboardButton("Manual", callback_data="wl_mode_manual")],
        [InlineKeyboardButton("Batal", callback_data="wl_cancel")]
    ])
    await update.message.reply_text(title_text("Mau Menambahkan Otomatis Atau Manual?"), reply_markup=kb)

async def helpwishlist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = (
        "Gunakan /cmdwishlist Untuk Menambahkan Atau Menghapus Item Dari Wishlist.\n\n"
        "Otomatis: Bot Akan Meminta Hingga 4 File Guest (Satu Per Akun) Dan Menjalankan Kategori Tertentu Per Akun.\n"
        "Manual: Anda Mengirimkan Langsung Daftar Item Id (Pisahkan Dengan Koma).\n\n"
        "Ikuti Instruksi Yang Muncul Di Chat."
    )
    await update.message.reply_text(title_text(txt))

async def wishlist_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    data = query.data

    if data == "wl_cancel":
        _states.pop(chat_id, None)
        await query.edit_message_text(title_text("Proses Dibatalkan."))
        return

    # Mode selection
    if data == "wl_mode_auto":
        _states[chat_id] = {"mode": "await_action", "runmode": "auto", "accounts_received": 0, "accounts_results": []}
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("Tambah", callback_data="wl_action_add"),
             InlineKeyboardButton("Hapus", callback_data="wl_action_remove")],
            [InlineKeyboardButton("Batal", callback_data="wl_cancel")]
        ])
        await query.edit_message_text(title_text("Pilih Aksi: Tambah Atau Hapus?"), reply_markup=kb)
        return

    if data == "wl_mode_manual":
        _states[chat_id] = {"mode": "await_action", "runmode": "manual"}
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("Tambah", callback_data="wl_action_add"),
             InlineKeyboardButton("Hapus", callback_data="wl_action_remove")],
            [InlineKeyboardButton("Batal", callback_data="wl_cancel")]
        ])
        await query.edit_message_text(title_text("Pilih Aksi: Tambah Atau Hapus?"), reply_markup=kb)
        return

    # Action select
    if data in ("wl_action_add", "wl_action_remove"):
        state = _states.get(chat_id, {})
        action = "add" if data == "wl_action_add" else "remove"
        state["action"] = action
        state["mode"] = "await_guest"
        _states[chat_id] = state
        await query.edit_message_text(title_text("Silakan Kirim File Guest (File .dat/.json)."))
        return

    await query.edit_message_text(title_text("Pilihan Tidak Dikenali."))

# Handle guest file uploads (both auto & manual)
async def handle_guest_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state:
        return

    if state.get("mode") not in ("await_guest",):
        # ignore if not expected
        return

    doc = update.message.document
    if not doc:
        await update.message.reply_text(title_text("Silakan Kirim File Sebagai Document (Bukan Photo)."))
        return

    # Save guest file
    work = Path(tempfile.mkdtemp(prefix="wl_guest_"))
    dest = work / doc.file_name
    try:
        file_obj = await context.bot.get_file(doc.file_id)
        await download_document_to_path(file_obj, dest)
    except Exception as e:
        shutil.rmtree(work, ignore_errors=True)
        await update.message.reply_text(title_text(f"Gagal Mendownload File Guest: {e}"))
        _states.pop(chat_id, None)
        return

    parsed = await parse_guest_file(dest)
    if not parsed:
        shutil.rmtree(work, ignore_errors=True)
        await update.message.reply_text(title_text("File Guest Tidak Valid Atau Tidak Mengandung UID/Password."))
        _states.pop(chat_id, None)
        return

    uid, pwd = parsed
    state["guest_tmp"] = str(work)
    state["uid"] = uid
    state["pwd"] = pwd

    # next step depending on runmode
    if state.get("runmode") == "manual":
        # Ask for item ids list directly
        state["mode"] = "await_manual_items"
        await update.message.reply_text(title_text("Silakan Kirim Daftar Item Id (Pisahkan Dengan Koma). Contoh: 710051003,710051002"))
        return
    else:
        # Auto mode: ask OB
        state["mode"] = "await_ob"
        await update.message.reply_text(title_text("File Guest Diterima. Silakan Masukkan Versi OB (Contoh: 51)."))
        return

# Handle OB input or manual items input
async def handle_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state:
        return

    text = (update.message.text or "").strip()

    # Cancel shortcut
    if text.lower() in ("batal", "cancel", "stop"):
        _states.pop(chat_id, None)
        await update.message.reply_text(title_text("Proses Dibatalkan."))
        return

    mode = state.get("mode")
    if mode == "await_ob":
        # Validate numeric OB
        if not text.isdigit():
            await update.message.reply_text(title_text("OB Tidak Valid. Silakan Masukkan Angka (Contoh: 51 atau 05)."))
            return
        ob_raw = int(text)
        ob_str = f"{ob_raw:02d}"
        state["ob_str"] = ob_str
        # In auto mode, we will process this account's assigned categories
        state["mode"] = "processing_account"
        # start background processing for this account
        asyncio.create_task(_process_account_auto(chat_id, state, update, context))
        await update.message.reply_text(title_text("Proses Dimulai. Silakan Tunggu."))
        return

    if mode == "await_manual_items":
        # parse comma-separated item ids
        items_raw = [p.strip() for p in text.split(",") if p.strip()]
        if not items_raw:
            await update.message.reply_text(title_text("Daftar Item Tidak Valid. Pastikan Memisahkan Dengan Koma."))
            return
        state["manual_items"] = items_raw
        state["mode"] = "processing_manual"
        asyncio.create_task(_process_manual_items(chat_id, state, update, context))
        await update.message.reply_text(title_text("Proses Dimulai. Silakan Tunggu."))
        return

    # else ignore
    return

# ---------------- processing helpers ----------------
async def _process_manual_items(chat_id: int, state: Dict[str, Any], update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Process manual items for single guest account (add/remove)."""
    uid = state.get("uid")
    pwd = state.get("pwd")
    action = state.get("action", "add")
    items = state.get("manual_items", [])
    if not uid or not pwd or not items:
        await context.bot.send_message(chat_id=chat_id, text=title_text("Data Kurang. Proses Dihentikan."))
        _states.pop(chat_id, None)
        return

    progress_msg = await context.bot.send_message(chat_id=chat_id, text=title_text("Memproses Item Manual..."))
    success_list = []
    fail_list = []

    timeout = aiohttp.ClientTimeout(total=None)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for idx, item_id in enumerate(items, start=1):
            ok, resp = await call_wishlist_api(session, action, item_id, uid, pwd)
            if ok:
                success_list.append(item_id)
            else:
                fail_list.append((item_id, resp))
            # update progress occasionally
            if idx % 1 == 0:
                await edit_safe(progress_msg, f"Memproses Item Manual\n{build_bar(idx, max(len(items), 1))}\nBerhasil: {len(success_list)} | Gagal: {len(fail_list)}")
            await asyncio.sleep(REQUEST_DELAY)

    # final messages
    await context.bot.send_message(chat_id=chat_id, text=title_text(f"{len(success_list)} Item Berhasil Ditambahkan." if action == "add" else f"{len(success_list)} Item Berhasil Dihapus."))
    if fail_list:
        failed_ids = ", ".join([f for f, _ in fail_list])
        await context.bot.send_message(chat_id=chat_id, text=title_text(f"{len(fail_list)} Item Gagal: {failed_ids}"))
    # cleanup guest tmp
    try:
        tmp = state.get("guest_tmp")
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        pass
    _states.pop(chat_id, None)

async def _process_account_auto(chat_id: int, state: Dict[str, Any], update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Process one guest account in auto mode.
    After done, if less than MAX_ACCOUNTS processed, bot will ask for next guest file,
    until MAX_ACCOUNTS or user cancels.
    """
    uid = state.get("uid")
    pwd = state.get("pwd")
    ob = state.get("ob_str")
    action = state.get("action", "add")
    runmode = state.get("runmode", "auto")

    if not (uid and pwd and ob):
        await context.bot.send_message(chat_id=chat_id, text=title_text("Data Kurang. Proses Dihentikan."))
        _states.pop(chat_id, None)
        return

    # Find which account index we are on
    acc_index = state.get("accounts_received", 0)  # 0-based
    # if not set, default 0
    # ensure index within bounds
    if acc_index >= MAX_ACCOUNTS:
        await context.bot.send_message(chat_id=chat_id, text=title_text("Batas Akun Tercapai."))
        _states.pop(chat_id, None)
        return

    # determine category list for this account
    try:
        categories = ACCOUNTS_CATEGORIES[acc_index]
    except IndexError:
        categories = []  # nothing to do

    total_added_account = 0
    total_attempts_account = 0

    progress_msg = await context.bot.send_message(chat_id=chat_id, text=title_text(f"Memulai Proses Untuk Akun Ke {acc_index+1}..."))
    timeout = aiohttp.ClientTimeout(total=None)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        # iterate categories for this account sequentially
        for prefix, display_name, pad in categories:
            added_in_category = 0
            consec_fail = 0
            attempt = 0

            await edit_safe(progress_msg, f"Kategori: {display_name}\n{build_bar(0)}\nStatus: Memulai...")
            # iterate suffix numbers
            for n in range(1, MAX_ATTEMPTS_PER_CATEGORY + 1):
                # stop if per-account limit reached
                if total_added_account >= MAX_PER_ACCOUNT:
                    await edit_safe(progress_msg, f"Target {MAX_PER_ACCOUNT} Item Tercapai Untuk Akun Ini. Berhenti Menambah Di Akun Ini.")
                    break

                attempt += 1
                total_attempts_account += 1
                suffix = str(n).zfill(pad)
                item_id = f"{prefix}{ob}{suffix}"

                ok, resp = await call_wishlist_api(session, action, item_id, uid, pwd)
                if ok:
                    consec_fail = 0
                    added_in_category += 1
                    total_added_account += 1
                    # update progress
                    if attempt % 1 == 0:
                        await edit_safe(progress_msg, f"Kategori: {display_name}\n{build_bar(attempt)}\nItem: {item_id}\nBerhasil Di Kategori: {added_in_category} | Total Akun: {total_added_account}")
                else:
                    consec_fail += 1
                    if attempt % 3 == 0 or consec_fail >= MAX_CONSECUTIVE_ERRORS:
                        await edit_safe(progress_msg, f"Kategori: {display_name}\n{build_bar(attempt)}\nItem: {item_id}\nGagal Berturut: {consec_fail}\nInfo: {str(resp)[:120]}")
                # stop category if many consecutive failures
                if consec_fail >= MAX_CONSECUTIVE_ERRORS:
                    await edit_safe(progress_msg, f"Kategori '{display_name}' Selesai (Skip Setelah {consec_fail} Kegagalan Berturut). Ditemukan {added_in_category} Item.")
                    break
                await asyncio.sleep(REQUEST_DELAY)

            # end category
            await asyncio.sleep(0.4)
            await edit_safe(progress_msg, f"Kategori '{display_name}' Selesai. Item Berhasil: {added_in_category}.")
            await asyncio.sleep(0.8)
            if total_added_account >= MAX_PER_ACCOUNT:
                break

    # after account processed
    # store result
    state.setdefault("accounts_results", []).append({"added": total_added_account, "attempts": total_attempts_account})
    state["accounts_received"] = state.get("accounts_received", 0) + 1

    await context.bot.send_message(chat_id=chat_id, text=title_text(f"Akun Ke {acc_index+1} Selesai. Item Berhasil: {total_added_account}"))

    # cleanup guest temp
    try:
        tmp = state.get("guest_tmp")
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        pass

    # If we still need next guest account (and haven't reached MAX_ACCOUNTS)
    if state.get("accounts_received", 0) < MAX_ACCOUNTS and state.get("runmode") == "auto":
        state["mode"] = "await_guest"
        _states[chat_id] = state
        await context.bot.send_message(chat_id=chat_id, text=title_text(f"Kirim File Guest Untuk Akun Ke {state['accounts_received']+1} (Jika Tidak, Kirim 'Batal' Untuk Menghentikan)."))
        return
    else:
        # finish overall process, show summary
        results = state.get("accounts_results", [])
        total_all = sum(r.get("added", 0) for r in results)
        # per-account breakdown
        summary_lines = []
        for i, r in enumerate(results, start=1):
            summary_lines.append(f"Akun {i}: {r.get('added',0)} Item")
        summary_text = " | ".join(summary_lines)
        await context.bot.send_message(chat_id=chat_id, text=title_text("Proses Selesai."))
        await context.bot.send_message(chat_id=chat_id, text=title_text(f"Detail: {summary_text}"))
        await context.bot.send_message(chat_id=chat_id, text=title_text(f"Total Item Yang Di Wishlist: {total_all} Item"))
        _states.pop(chat_id, None)
        return

# ---------- register ----------
def register_wishlist(app):
    """
    Registrasi semua handler untuk fitur /cmdwishlist dan /helpwishlist.
    Pastikan tidak bentrok dengan handler fitur lain.
    """
    app.add_handler(CommandHandler("cmdwishlist", cmdwishlist))
    app.add_handler(CommandHandler("helpwishlist", helpwishlist))
    app.add_handler(CallbackQueryHandler(wishlist_callback_handler, pattern="^wl_"))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_guest_file))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_input))