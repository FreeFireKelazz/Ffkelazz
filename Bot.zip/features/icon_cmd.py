import asyncio
import aiohttp
import aiofiles
import os
import shutil
import zipfile
import tempfile
import time
from pathlib import Path
from typing import Dict, Any, List

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# ============ CONFIG ============
TELEGRAM_MAX_FILE_BYTES = int(os.getenv("TELEGRAM_MAX_FILE_BYTES", str(2 * 1024 * 1024 * 1024)))
DL_CHUNK = 32 * 1024                 # 32 KB chunk
PROGRESS_UPDATE_MIN_SEC = 0.8
CONCURRENT_CATEGORY_TASKS = int(os.getenv("ICON_CONCURRENT_CATEGORIES", "6"))
MAX_INDEX_SAFE = 9999                # safety upper bound per category
# ================================

_states: Dict[int, Dict[str, Any]] = {}  # chat_id -> state

# Category mapping: (itemid, folder_name, number_width)
CATEGORY_DEFS: List[tuple] = [
    ("9010", "banner", 3),
    ("9020", "headpic", 3),
    ("9030", "lootbox", 3),
    ("9040", "backpack", 3),
    ("9050", "parachute", 3),
    ("9060", "skateboard", 3),
    ("90710", "weapon", 2),
    ("9080", "vehicle", 3),
    ("9090", "emote", 3),
    ("9100", "pin", 3),
    ("91100", "skywing", 2),
    ("9120", "arrival_animation", 3),
    ("9130", "music", 3),
    ("9140", "look_changer", 3),
    ("9180", "medkit_posture", 3),
    ("9190", "jump_posture", 3),
    ("9200", "fall_posture", 3),
    ("9210", "voice_pack", 3),
    ("9220", "skill_skin", 3),
    ("9230", "final_shot", 3),
    ("9095", "super_emote", 3),
    ("9250", "battle_card", 3),
    ("7100", "bundle", 3),
    ("2030", "top_outfit", 3),
    ("2040", "bottom_outfit", 3),
    ("2050", "shoes_outfit", 3),
    ("2110", "head_outfit", 3),
    ("2140", "facepaint", 3),
    ("8010", "token", 3),
    ("92600", "frame", 2),
]

BASE_URLS = {
    "advance": "https://dl.cdn.freefiremobile.com/advance/ABHotUpdates/IconCDN/other/",
    "live":    "https://dl.cdn.freefiremobile.com/live/ABHotUpdates/IconCDN/other/",
}

# ---------- helpers ----------
def format_ob(ob_raw: str) -> str:
    try:
        ob_i = int(ob_raw)
    except Exception:
        ob_i = 0
    return str(ob_i).zfill(2)


def human_size(nbytes: int) -> str:
    if nbytes is None:
        return "0B"
    n = float(nbytes)
    if n >= 1024 ** 3:
        return f"{n / (1024 ** 3):.2f} GB"
    if n >= 1024 ** 2:
        return f"{n / (1024 ** 2):.2f} MB"
    if n >= 1024:
        return f"{n / 1024:.2f} KB"
    return f"{n} B"


def build_bar(done: int, total: int, length: int = 20) -> str:
    # If total unknown (0), we build bar based on done (capped)
    if total and total > 0:
        percent = int(done / total * 100)
        filled = int(length * percent / 100)
    else:
        # fallback: approximate progress by mapping done to bar
        # ensure at least one char when done>0
        filled = min(length, max(0, done % (length + 1)))
        percent = 0
    filled = max(0, min(length, filled))
    bar = "█" * filled + "░" * (length - filled)
    if total and total > 0:
        return f"[{bar}] {percent}% ({done}/{total})"
    else:
        return f"[{bar}] ({done})"


async def edit_progress_safe(msg_obj, text: str):
    try:
        await msg_obj.edit_text(text)
    except Exception:
        # ignore edit issues (rate limits)
        pass

# ---------- single download ----------
async def _download_single(session: aiohttp.ClientSession, url: str, dest: Path, timeout=40) -> bool:
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
            if resp.status != 200:
                return False
            dest.parent.mkdir(parents=True, exist_ok=True)
            async with aiofiles.open(dest, "wb") as fh:
                async for chunk in resp.content.iter_chunked(DL_CHUNK):
                    if not chunk:
                        break
                    await fh.write(chunk)
            return True
    except Exception:
        return False

# ---------- per-category sequential checking ----------
async def download_category_sequential(session: aiohttp.ClientSession, base_url: str,
                                       itemid: str, folder_name: str, num_width: int, ob_str: str,
                                       out_root: Path, progress_state: Dict[str, Any]) -> int:
    downloaded = 0
    consecutive_failures = 0
    index = 1
    folder = out_root / folder_name
    last_update = 0.0

    # we track "done_for_bar" as total attempts for bar building (not exact total)
    done_for_bar = 0

    while index <= MAX_INDEX_SAFE and consecutive_failures < 10:
        num_str = str(index).zfill(num_width)
        filename = f"{itemid}{ob_str}{num_str}.png"
        url = base_url + filename
        dest = folder / filename

        ok = await _download_single(session, url, dest)
        done_for_bar += 1
        if ok:
            downloaded += 1
            consecutive_failures = 0
        else:
            consecutive_failures += 1

        # occasionally update shared progress_state for the category
        now = time.time()
        if now - last_update >= PROGRESS_UPDATE_MIN_SEC:
            progress_state["current_cat"] = folder_name
            progress_state["cat_downloaded"] = downloaded
            progress_state["cat_fail_streak"] = consecutive_failures
            progress_state["cat_index"] = index
            progress_state["cat_attempts"] = done_for_bar
            last_update = now

        index += 1

    # remove empty folder if nothing downloaded
    if folder.exists():
        try:
            if not any(folder.iterdir()):
                shutil.rmtree(folder)
        except Exception:
            pass

    return downloaded

# ---------- orchestrator (parallel categories with semaphore) ----------
async def run_icon_flow_parallel(kind: str, ob_raw: str, update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    ob = format_ob(ob_raw)
    base_url = BASE_URLS.get(kind)
    if not base_url:
        await update.message.reply_text("⚠️ Internal error: unknown server type.")
        return

    work_dir = Path(tempfile.mkdtemp(prefix="coolbot_icons_"))
    out_root = work_dir / f"OB{ob}_Icon"
    out_root.mkdir(parents=True, exist_ok=True)

    progress_msg = await update.message.reply_text(f"📥 Memulai Mengunduh Icon ({kind}) — OB{ob} ...")
    progress_state: Dict[str, Any] = {
        "total_downloaded": 0,
        "current_cat": None,
        "cat_downloaded": 0,
        "cat_fail_streak": 0,
        "cat_index": 0,
        "cat_attempts": 0,
        "start_time": time.time(),
    }

    # start background task to update the single progress message regularly
    async def progress_updater():
        last_text = None
        while True:
            # if process finished flag is set, break after last edit
            if progress_state.get("finished"):
                try:
                    await edit_progress_safe(progress_msg, progress_state.get("final_text", "✅ Selesai."))
                except Exception:
                    pass
                break

            # build detail progress text
            cur_cat = progress_state.get("current_cat") or "—"
            cd = progress_state.get("cat_downloaded", 0)
            cs = progress_state.get("cat_fail_streak", 0)
            ci = progress_state.get("cat_index", 0)
            ca = progress_state.get("cat_attempts", 0)
            total_dl = progress_state.get("total_downloaded", 0)

            # we don't know exact total icons per category, so bar is indicative using attempts
            bar = build_bar(ca, 100)  # use 100 as a visual scale (not exact)
            elapsed = int(time.time() - progress_state.get("start_time", time.time()))
            text = (
                f"📦 Kategori: {cur_cat}\n"
                f"{bar}\n"
                f"✅ {cd} Berhasil | ❌ {cs} Gagal | 🔍 cek idx: {ci}\n"
                f"⏱️ Elapsed: {elapsed}s — Total Download: {total_dl}"
            )

            # only edit if changed to reduce edits
            if text != last_text:
                await edit_progress_safe(progress_msg, text)
                last_text = text

            await asyncio.sleep(PROGRESS_UPDATE_MIN_SEC)

    # run progress_updater in background
    updater_task = asyncio.create_task(progress_updater())

    total_downloaded = 0
    sem = asyncio.Semaphore(CONCURRENT_CATEGORY_TASKS)

    async with aiohttp.ClientSession() as session:
        async def category_task(entry):
            itemid, name, w = entry
            async with sem:
                # update message right before starting category
                progress_state["current_cat"] = name
                progress_state["cat_downloaded"] = 0
                progress_state["cat_fail_streak"] = 0
                progress_state["cat_index"] = 0
                progress_state["cat_attempts"] = 0
                await edit_progress_safe(progress_msg, f"📦 Memulai Kategori: {name} ...")
                got = await download_category_sequential(session, base_url, itemid, name, w, ob, out_root, progress_state)
                # merge result
                progress_state["total_downloaded"] = progress_state.get("total_downloaded", 0) + (got or 0)
                await edit_progress_safe(progress_msg, f"📦 Selesai Kategori: {name} — {got} file(s). Total so far: {progress_state['total_downloaded']}")
                # small throttle
                await asyncio.sleep(0.2)
                return got

        # create tasks for all categories
        tasks = [asyncio.create_task(category_task(entry)) for entry in CATEGORY_DEFS]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    # stop progress updater and set final message text
    total_downloaded = progress_state.get("total_downloaded", 0)
    if total_downloaded == 0:
        progress_state["final_text"] = "Aowkwok Gada Jir😂 (Icon Tidak Ditemukan Untuk Versi OB Ini)."
        progress_state["finished"] = True
        await updater_task
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        return

    # compress into one zip containing all category folders
    archive_name = f"OB{ob}_Icon"
    zip_file_path = work_dir / f"{archive_name}.zip"
    try:
        # create zip using zipfile to have fine control
        with zipfile.ZipFile(zip_file_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(out_root):
                for f in files:
                    abs_p = Path(root) / f
                    rel = abs_p.relative_to(out_root)
                    zf.write(abs_p, arcname=str(rel))
    except Exception as e:
        progress_state["final_text"] = f"⚠️ Gagal Mengompres Hasil: {e}"
        progress_state["finished"] = True
        await updater_task
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        return

    size = zip_file_path.stat().st_size
    progress_state["final_text"] = f"🗜️ Kompres Selesai — {human_size(size)}. Mengirim Ke Telegram..."
    progress_state["finished"] = True
    await updater_task  # wait final edit

    # send zip as new document (not editing previous message)
    try:
        if size <= TELEGRAM_MAX_FILE_BYTES:
            def open_and_send():
                with open(zip_file_path, "rb") as f:
                    context.bot.send_document(chat_id=chat_id, document=f, filename=zip_file_path.name)
            await asyncio.to_thread(open_and_send)
        else:
            # fallback upload to transfer.sh (best-effort)
            link = None
            try:
                async with aiohttp.ClientSession() as ses:
                    with open(zip_file_path, "rb") as fh:
                        async with ses.put(f"https://transfer.sh/{zip_file_path.name}", data=fh, timeout=600) as resp:
                            if resp.status in (200, 201):
                                link = (await resp.text()).strip()
            except Exception:
                link = None
            if link:
                await update.message.reply_text(f"🔗 Hasil diupload: {link}")
            else:
                await update.message.reply_text("❌ Gagal upload fallback dan file terlalu besar untuk Telegram.")
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal Mengirim zip: {e}")

    # cleanup
    try:
        shutil.rmtree(work_dir)
    except Exception:
        pass

    # final "Selesai" edit
    try:
        await edit_progress_safe(progress_msg, "✅ Proses Selesai. File dikirim.")
    except Exception:
        pass


# ---------- Telegram handlers ----------
async def cmdicon(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    _states[chat_id] = {"mode": "await_server_choice"}
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("Advance Server", callback_data="icon_server_advance"),
         InlineKeyboardButton("Live Server", callback_data="icon_server_live")],
        [InlineKeyboardButton("Batal", callback_data="icon_cancel")]
    ])
    await update.message.reply_text(
        "🔽 Pilih Server Icon Yang Mau Didownload:\n1. Advance = Icon Rilis Lebih Awal Sebelum Live\n2. Live = Icon Rilis 1-2 Hari Sebelum Update.",
        reply_markup=kb,
    )


async def helpicon(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("Kembali", callback_data="help_back")]])
    await update.message.reply_text(
        "📘 Command: /cmdicon\n1. Pilih Server Advance/Live\n2. Ketik Versi OB Setelah Itu Tunggu\nCatatan: Bot Akan Mendownload Seluruh Icon Dari Server Dan Versi OB Yang Kamu Pilih, Jika Icon Tidak Ada, Berarti Icon Belum Ditambahkan Atau Icon Dihapus🗿",
        reply_markup=kb,
    )


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    data = query.data
    if data == "icon_cancel":
        _states.pop(chat_id, None)
        await query.edit_message_text("❌ Proses Dibatalkan.")
        return
    if data == "help_back":
        await query.edit_message_text("🏠 Kembali. Gunakan /cmdicon Untuk Memulai.")
        return
    if data.startswith("icon_server_"):
        server = "advance" if data.endswith("advance") else "live"
        _states[chat_id] = {"mode": "await_ob", "server": server}
        await query.edit_message_text(f"✅ Server Dipilih: {server}. Silakan Ketik Versi OB.")


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state:
        return

    text = (update.message.text or "").strip()
    if text.lower() in ("batal", "cancel", "stop"):
        _states.pop(chat_id, None)
        await update.message.reply_text("❌ Proses Dibatalkan.")
        return

    if state.get("mode") == "await_ob":
        server = state.get("server")
        ob_raw = text
        try:
            int(ob_raw)
        except Exception:
            await update.message.reply_text("⚠️ Versi OB Tidak Valid. Kirim Angka Contoh: 50.")
            return
        _states[chat_id]["mode"] = "running"
        await update.message.reply_text(f"🔁 Memulai Mengunduh Icon Untu `{server}` Server,Versi OB{format_ob(ob_raw)}. Proses Download Mungkin Butuh Sedikit Waktu.")
        # background task
        asyncio.create_task(run_icon_flow_parallel(server, ob_raw, update, context))
        return

    await update.message.reply_text("⚠️ Sedang Dalam Proses Atau Flow Tidak  Tidak Dikenali. Gunakan /cmdicon Untuk Memulai.")


# ---------- register ----------
def register_icon(app):
    app.add_handler(CommandHandler("cmdicon", cmdicon))
    app.add_handler(CommandHandler("helpicon", helpicon))
    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^icon_"))
    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^help_back$"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))