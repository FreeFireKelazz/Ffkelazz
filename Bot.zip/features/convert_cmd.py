# features/convert_cmd.py
import asyncio
import aiohttp
import aiofiles
import os
import shutil
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Dict, Any, Tuple, List, Optional

from PIL import Image

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# -------------- CONFIG --------------
TELEGRAM_MAX_FILE_BYTES = int(os.getenv("TELEGRAM_MAX_FILE_BYTES", str(2 * 1024 * 1024 * 1024)))
PROGRESS_UPDATE_MIN_SEC = 0.9
PROGRESS_BAR_LEN = 20
DL_TIMEOUT = 120
# -------------------------------------

_states: Dict[int, Dict[str, Any]] = {}  # per-chat state

# ---------- helpers ----------
def build_bar(done: int, total: int, length: int = PROGRESS_BAR_LEN) -> str:
    if total and total > 0:
        percent = int(done / total * 100)
        filled = int(length * percent / 100)
    else:
        percent = 0
        filled = min(length, done % (length + 1))
    filled = max(0, min(length, filled))
    bar = "█" * filled + "░" * (length - filled)
    if total and total > 0:
        return f"[{bar}] {percent}% ({done}/{total})"
    else:
        return f"[{bar}] ({done})"

async def edit_progress_safe(msg_obj, text: str):
    try:
        await msg_obj.edit_text(text)
    except Exception:
        pass

async def upload_to_transfersh(file_path: Path) -> Optional[str]:
    """Best-effort fallback upload to transfer.sh"""
    try:
        url = f"https://transfer.sh/{file_path.name}"
        async with aiohttp.ClientSession() as ses:
            async with ses.put(url, data=open(file_path, "rb"), timeout=600) as resp:
                if resp.status in (200, 201):
                    return (await resp.text()).strip()
    except Exception:
        return None
    return None

def basename_key(name: str) -> Optional[Tuple[str, str]]:
    """
    If filename ends with _rgb.png or _sa.png (case-insensitive),
    return (base, kind) where kind is 'rgb' or 'sa'.
    """
    n = name.replace("\\", "/").split("/")[-1]
    ln = n.lower()
    if ln.endswith("_rgb.png"):
        return (n[: -len("_rgb.png")], "rgb")
    if ln.endswith("_sa.png"):
        return (n[: -len("_sa.png")], "sa")
    return None

# ---------- image merge (blocking) ----------
def merge_rgb_sa_blocking(rgb_path: Path, sa_path: Path, out_path: Path) -> None:
    """Open rgb and sa, create RGBA and save to out_path. Blocking - run in thread."""
    rgb = Image.open(rgb_path).convert("RGBA")
    sa_img = Image.open(sa_path).convert("L")  # alpha in L mode
    # Resize SA to rgb size if needed
    if sa_img.size != rgb.size:
        sa_img = sa_img.resize(rgb.size, resample=Image.BILINEAR)
    r, g, b, _ = rgb.split()
    rgba = Image.merge("RGBA", (r, g, b, sa_img))
    rgba.save(out_path, format="PNG", optimize=True)

# ---------- handlers ----------
async def cmdconvert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    _states[chat_id] = {"mode": "await_choice"}
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("File (kirim 2 png)", callback_data="conv_mode_file"),
         InlineKeyboardButton("ZIP (kirim 1 zip)", callback_data="conv_mode_zip")],
        [InlineKeyboardButton("Batal", callback_data="conv_cancel")]
    ])
    await update.message.reply_text(
        "🔽 Pilih mode konversi:\n• File = kirim 2 dokumen PNG (nama_kelazz_rgb.png & nama_kelazz_sa.png)\n• ZIP = kirim 1 file .zip (mencari pasangan di dalamnya)",
        reply_markup=kb
    )

async def helpconvert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📘 /cmdconvert -> gabungkan RGB + SA menjadi PNG.\nMode File: kirim 2 file PNG dengan nama dasar sama.\nMode ZIP: kirim .zip yang berisi file PNG (bisa di dalam folder), bot akan mencari pasangan *_rgb.png dan *_sa.png dan menggabungkannya.\n#TODO: tambahkan tips."
    )

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    data = query.data

    if data == "conv_cancel":
        _states.pop(chat_id, None)
        await query.edit_message_text("❌ Proses dibatalkan.")
        return

    if data == "conv_mode_file":
        _states[chat_id] = {"mode": "await_files", "files": []}
        await query.edit_message_text("📁 Mode File dipilih. Silakan kirim **2 dokumen PNG** (satu *_rgb.png dan satu *_sa.png) sebagai document (bukan photo).")
        return

    if data == "conv_mode_zip":
        _states[chat_id] = {"mode": "await_zip"}
        await query.edit_message_text("🗜️ Mode ZIP dipilih. Silakan kirim file .zip yang berisi file *_rgb.png dan *_sa.png (bisa di dalam folder).")
        return

    await query.edit_message_text("⚠️ Callback belum diimplementasi.")

async def _download_telegram_file(file_obj, dest_path: Path):
    """Download telegram File to dest_path. file_obj is telegram.File (async)."""
    # file_obj.download_to_drive is coroutine in PTB v20
    await file_obj.download_to_drive(str(dest_path))

async def _handle_file_mode(chat_id: int, state: Dict[str, Any], update: Update, context: ContextTypes.DEFAULT_TYPE):
    files = state.get("files", [])
    # We expect 2 files only
    if len(files) < 2:
        await update.message.reply_text("⚠️ Tidak menerima file. Pastikan mengirim sebagai dokumen.")
        _states.pop(chat_id, None)
        return

    # Check names and find rgb & sa
    pairs = {}
    for p in files:
        key = basename_key(p.name)
        if not key:
            await update.message.reply_text(f"⚠️ File '{p.name}' tidak sesuai format (_rgb.png atau _sa.png). Proses dibatalkan.")
            _states.pop(chat_id, None)
            return
        base, kind = key
        pairs.setdefault(base, {})[kind] = p

    # find exactly one base with both rgb & sa; if multiple, process all pairs
    results = []
    for base, dic in pairs.items():
        if "rgb" in dic and "sa" in dic:
            results.append((base, dic["rgb"].path, dic["sa"].path))
        else:
            # ask user to resend if any missing
            # If multiple files provided and some mismatch, inform
            missing = []
            if "rgb" not in dic:
                missing.append("rgb")
            if "sa" not in dic:
                missing.append("sa")
            await update.message.reply_text(f"⚠️ File untuk '{base}' tidak lengkap (missing: {', '.join(missing)}). Pastikan mengirim pasangan nama yang sama.")
            _states.pop(chat_id, None)
            return

    # Process each pair (likely only one)
    for base, rgb_path, sa_path in results:
        out_name = f"{base}.png"
        out_path = Path(tempfile.mkdtemp()) / out_name
        try:
            await asyncio.to_thread(merge_rgb_sa_blocking, Path(rgb_path), Path(sa_path), out_path)
            # send as document
            def send_doc():
                with open(out_path, "rb") as fh:
                    context.bot.send_document(chat_id=chat_id, document=fh, filename=out_name)
            await asyncio.to_thread(send_doc)
        except Exception as e:
            await update.message.reply_text(f"❌ Gagal menggabungkan {base}: {e}")
        finally:
            try:
                shutil.rmtree(Path(rgb_path).parent)
            except Exception:
                pass

    await update.message.reply_text("✅ Selesai.")
    _states.pop(chat_id, None)

async def _process_zip_and_convert(zip_path: Path, out_dir: Path, progress_state: Dict[str, Any]):
    """
    Blocking heavy operations: extract zip and find pairs, merge images.
    This function runs in thread via asyncio.to_thread.
    Returns list of output file paths.
    """
    # Extract zip
    extract_dir = out_dir / "extracted"
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(path=extract_dir)

    # Walk and collect png files
    files = []
    for p in extract_dir.rglob("*.png"):
        files.append(p)

    # map base -> {'rgb':path, 'sa':path}
    pairs_map: Dict[str, Dict[str, Path]] = {}
    for f in files:
        key = basename_key(f.name)
        if not key:
            continue
        base, kind = key
        pairs_map.setdefault(base, {})[kind] = f

    # create outputs
    outputs: List[Path] = []
    for base, dic in pairs_map.items():
        if "rgb" in dic and "sa" in dic:
            out_p = out_dir / f"{base}.png"
            try:
                merge_rgb_sa_blocking(dic["rgb"], dic["sa"], out_p)
                outputs.append(out_p)
            except Exception:
                # skip problematic pairs, continue
                continue
    return outputs

async def _handle_zip_mode(chat_id: int, state: Dict[str, Any], zip_file_path: Path, update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Prepare working dir
    work_dir = Path(tempfile.mkdtemp(prefix="conv_zip_"))
    out_dir = work_dir / "out"
    out_dir.mkdir(parents=True, exist_ok=True)

    # progress message
    progress_msg = await update.message.reply_text("📦 Menerima ZIP... memulai ekstraksi & konversi.")
    progress_state = {
        "total": 0,
        "done": 0,
        "start_time": time.time(),
        "finished": False,
    }

    # run extract & convert in thread (blocking)
    try:
        outputs = await asyncio.to_thread(_process_zip_and_convert, zip_file_path, out_dir, progress_state)
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal proses ZIP: {e}")
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        _states.pop(chat_id, None)
        return

    total = len(outputs)
    progress_state["total"] = total

    if total == 0:
        await edit_progress_safe(progress_msg, "Aowkwok Gada Jir😂 (Tidak ada pasangan *_rgb.png & *_sa.png ditemukan).")
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        _states.pop(chat_id, None)
        return

    # send outputs one-by-one, editing progress message
    last_text = None
    for idx, out_file in enumerate(outputs, start=1):
        progress_state["done"] = idx - 1
        text = f"📦 Mengonversi ZIP — Proses: {build_bar(idx-1, total)}\n⏱️ Elapsed: {int(time.time()-progress_state['start_time'])}s\n🔁 Mengirim {out_file.name} ({idx}/{total})..."
        if text != last_text:
            await edit_progress_safe(progress_msg, text)
            last_text = text
        try:
            size = out_file.stat().st_size
            if size <= TELEGRAM_MAX_FILE_BYTES:
                def send_doc():
                    with open(out_file, "rb") as fh:
                        context.bot.send_document(chat_id=chat_id, document=fh, filename=out_file.name)
                await asyncio.to_thread(send_doc)
            else:
                # fallback
                link = await upload_to_transfersh(out_file)
                if link:
                    await context.bot.send_message(chat_id=chat_id, text=f"🔗 {out_file.name}: {link}")
                else:
                    await context.bot.send_message(chat_id=chat_id, text=f"❌ Gagal kirim {out_file.name} (terlalu besar).")
        except Exception as e:
            await context.bot.send_message(chat_id=chat_id, text=f"⚠️ Gagal kirim {out_file.name}: {e}")
        # cleanup single output if desired (keep for zip removal)
        try:
            out_file.unlink(missing_ok=True)
        except Exception:
            pass

    # final edit + cleanup
    await edit_progress_safe(progress_msg, "✅ Semua selesai. Semua file telah dikirim.")
    try:
        shutil.rmtree(work_dir)
        zip_file_path.unlink(missing_ok=True)
    except Exception:
        pass
    _states.pop(chat_id, None)

# ---------- message handler ----------
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state:
        return

    text = (update.message.text or "").strip().lower()

    # cancel shortcuts
    if text in ("batal", "cancel", "stop"):
        _states.pop(chat_id, None)
        await update.message.reply_text("❌ Proses dibatalkan.")
        return

    mode = state.get("mode")

    # ---------- FILE MODE ----------
    if mode == "await_files":
        # Expect documents; may receive multiple messages - we collect until 2 docs received
        doc = update.message.document
        if not doc:
            await update.message.reply_text("⚠️ Kirim file sebagai **Document** (bukan photo).")
            return
        # store name & path
        work = Path(tempfile.mkdtemp(prefix="conv_files_"))
        dest = work / doc.file_name
        file_obj = await context.bot.get_file(doc.file_id)
        try:
            await _download_telegram_file(file_obj, dest)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Gagal download file: {e}")
            shutil.rmtree(work, ignore_errors=True)
            _states.pop(chat_id, None)
            return
        # store metadata
        state.setdefault("files_meta", []).append({"name": doc.file_name, "path": str(dest)})
        # if we have 2 files, process
        if len(state.get("files_meta", [])) >= 2:
            # convert structure to expected by handler
            files = []
            for m in state.get("files_meta", []):
                class Obj:
                    pass
                o = Obj()
                o.name = m["name"]
                o.path = m["path"]
                files.append(o)
            state["files"] = files
            await _handle_file_mode(chat_id, state, update, context)
        else:
            await update.message.reply_text("✅ File diterima. Silakan kirim file kedua.")

        return

    # ---------- ZIP MODE ----------
    if mode == "await_zip":
        doc = update.message.document
        if not doc:
            await update.message.reply_text("⚠️ Kirim file .zip sebagai Document.")
            return
        if not doc.file_name.lower().endswith(".zip"):
            await update.message.reply_text("⚠️ File bukan .zip. Silakan kirim file ZIP.")
            return

        work = Path(tempfile.mkdtemp(prefix="conv_ziprecv_"))
        dest = work / doc.file_name
        file_obj = await context.bot.get_file(doc.file_id)
        try:
            await _download_telegram_file(file_obj, dest)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Gagal download ZIP: {e}")
            shutil.rmtree(work, ignore_errors=True)
            _states.pop(chat_id, None)
            return

        # kick off processing in background
        asyncio.create_task(_handle_zip_mode(chat_id, state, dest, update, context))
        await update.message.reply_text("📥 ZIP diterima — mulai proses ekstraksi & konversi. Silakan tunggu...")

        return

    # other modes or unknown
    await update.message.reply_text("⚠️ Flow tidak dikenali. Gunakan /cmdconvert untuk mulai.")

# ---------- register ----------
def register_convert(app):
    app.add_handler(CommandHandler("cmdconvert", cmdconvert))
    app.add_handler(CommandHandler("helpconvert", helpconvert))
    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^convert_"))
    app.add_handler(MessageHandler(filters.Document.ALL & ~filters.COMMAND, message_handler))