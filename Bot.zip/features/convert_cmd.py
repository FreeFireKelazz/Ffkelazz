# features/convert_cmd.py
import asyncio
import aiohttp
import aiofiles
import os
import shutil
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Dict, Any, Tuple, List, Optional

from PIL import Image

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

# -------------- CONFIG --------------
TELEGRAM_MAX_FILE_BYTES = int(os.getenv("TELEGRAM_MAX_FILE_BYTES", str(2 * 1024 * 1024 * 1024)))
PROGRESS_UPDATE_MIN_SEC = 0.9
PROGRESS_BAR_LEN = 20
DL_TIMEOUT = 120
# -------------------------------------

_states: Dict[int, Dict[str, Any]] = {}  # per-chat state

# ---------- helpers ----------
def build_bar(done: int, total: int, length: int = PROGRESS_BAR_LEN) -> str:
    if total and total > 0:
        percent = int(done / total * 100)
        filled = int(length * percent / 100)
    else:
        percent = 0
        filled = min(length, done % (length + 1))
    filled = max(0, min(length, filled))
    bar = "█" * filled + "░" * (length - filled)
    if total and total > 0:
        return f"[{bar}] {percent}% ({done}/{total})"
    else:
        return f"[{bar}] ({done})"

async def edit_progress_safe(msg_obj, text: str):
    try:
        await msg_obj.edit_text(text)
    except Exception:
        pass

async def upload_to_transfersh(file_path: Path) -> Optional[str]:
    """Best-effort fallback upload to transfer.sh"""
    try:
        url = f"https://transfer.sh/{file_path.name}"
        async with aiohttp.ClientSession() as ses:
            # aiohttp can accept a file-like; use aiofiles to read chunk-wise would be better,
            # but transfer.sh is simple — read bytes (careful with very large files)
            async with aiofiles.open(file_path, "rb") as fh:
                data = await fh.read()
            async with ses.put(url, data=data, timeout=600) as resp:
                if resp.status in (200, 201):
                    return (await resp.text()).strip()
    except Exception:
        return None
    return None

def basename_key(name: str) -> Optional[Tuple[str, str]]:
    """
    If filename ends with _rgb.png or _sa.png (case-insensitive),
    return (base, kind) where kind is 'rgb' or 'sa'.
    """
    n = name.replace("\\", "/").split("/")[-1]
    ln = n.lower()
    if ln.endswith("_rgb.png"):
        return (n[: -len("_rgb.png")], "rgb")
    if ln.endswith("_sa.png"):
        return (n[: -len("_sa.png")], "sa")
    return None

# ---------- image merge (blocking) ----------
def merge_rgb_sa_blocking(rgb_path: Path, sa_path: Path, out_path: Path) -> None:
    """Open rgb and sa, create RGBA and save to out_path. Blocking - run in thread."""
    rgb = Image.open(rgb_path).convert("RGBA")
    sa_img = Image.open(sa_path).convert("L")  # alpha in L mode
    # Resize SA to rgb size if needed
    if sa_img.size != rgb.size:
        sa_img = sa_img.resize(rgb.size, resample=Image.BILINEAR)
    r, g, b, _ = rgb.split()
    rgba = Image.merge("RGBA", (r, g, b, sa_img))
    # ensure parent exists
    out_path.parent.mkdir(parents=True, exist_ok=True)
    rgba.save(out_path, format="PNG", optimize=True)

# ---------- handlers ----------
async def cmdconvert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    _states[chat_id] = {"mode": "await_choice"}
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("File (kirim 2 png)", callback_data="conv_mode_file"),
         InlineKeyboardButton("ZIP (kirim 1 zip)", callback_data="conv_mode_zip")],
        [InlineKeyboardButton("Batal", callback_data="conv_cancel")]
    ])
    await update.message.reply_text(
        "🔽 Pilih mode konversi:\n• File = kirim 2 dokumen PNG (nama_kelazz_rgb.png & nama_kelazz_sa.png)\n• ZIP = kirim 1 file .zip (mencari pasangan di dalamnya)",
        reply_markup=kb
    )

async def helpconvert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📘 /cmdconvert -> gabungkan RGB + SA menjadi PNG.\nMode File: kirim 2 file PNG dengan nama dasar sama.\nMode ZIP: kirim .zip yang berisi file PNG (bisa di dalam folder), bot akan mencari pasangan *_rgb.png dan *_sa.png dan menggabungkannya.\n#TODO: tambahkan tips."
    )

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.message.chat_id
    data = query.data

    if data == "conv_cancel":
        _states.pop(chat_id, None)
        await query.edit_message_text("❌ Proses dibatalkan.")
        return

    if data == "conv_mode_file":
        _states[chat_id] = {"mode": "await_files", "files_meta": []}
        await query.edit_message_text("📁 Mode File dipilih. Silakan kirim **2 dokumen PNG** (satu *_rgb.png dan satu *_sa.png) sebagai document (bukan photo).")
        return

    if data == "conv_mode_zip":
        _states[chat_id] = {"mode": "await_zip"}
        await query.edit_message_text("🗜️ Mode ZIP dipilih. Silakan kirim file .zip yang berisi file *_rgb.png dan *_sa.png (bisa di dalam folder).")
        return

    await query.edit_message_text("⚠️ Callback belum diimplementasi.")

async def _download_telegram_file(file_obj, dest_path: Path):
    """Download telegram File to dest_path. file_obj is telegram.File (async)."""
    # file_obj.download_to_drive is coroutine in PTB v20
    await file_obj.download_to_drive(str(dest_path))

async def _handle_file_mode(chat_id: int, state: Dict[str, Any], update: Update, context: ContextTypes.DEFAULT_TYPE):
    files_meta = state.get("files_meta", [])
    if not files_meta:
        await update.message.reply_text("⚠️ Tidak ada file ditemukan.")
        _states.pop(chat_id, None)
        return

    # transform to helper objects
    pairs = {}
    for m in files_meta:
        name = m.get("name")
        path = Path(m.get("path"))
        key = basename_key(name)
        if not key:
            await update.message.reply_text(f"⚠️ File '{name}' tidak sesuai format (_rgb.png atau _sa.png). Proses dibatalkan.")
            _states.pop(chat_id, None)
            return
        base, kind = key
        pairs.setdefault(base, {})[kind] = path

    # find pairs and process
    any_processed = False
    for base, dic in pairs.items():
        if "rgb" in dic and "sa" in dic:
            any_processed = True
            out_name = f"{base}.png"
            out_path = Path(tempfile.mkdtemp()) / out_name
            try:
                await asyncio.to_thread(merge_rgb_sa_blocking, dic["rgb"], dic["sa"], out_path)
                # send as document (await properly)
                size = out_path.stat().st_size if out_path.exists() else 0
                if size <= TELEGRAM_MAX_FILE_BYTES:
                    with open(out_path, "rb") as fh:
                        await context.bot.send_document(chat_id=chat_id, document=fh, filename=out_name)
                else:
                    link = await upload_to_transfersh(out_path)
                    if link:
                        await context.bot.send_message(chat_id=chat_id, text=f"🔗 {out_name}: {link}")
                    else:
                        await context.bot.send_message(chat_id=chat_id, text=f"❌ {out_name} terlalu besar & gagal diupload.")
            except Exception as e:
                await update.message.reply_text(f"❌ Gagal menggabungkan {base}: {e}")
            finally:
                # cleanup the temporary folder that contained inputs (if they were saved in tmp)
                try:
                    tmp_parent = dic["rgb"].parent
                    shutil.rmtree(tmp_parent, ignore_errors=True)
                except Exception:
                    pass

    if not any_processed:
        await update.message.reply_text("⚠️ Tidak ditemukan pasangan rgb/sa yang cocok di file yang dikirim.")
    else:
        await update.message.reply_text("✅ Selesai.")
    _states.pop(chat_id, None)

async def _process_zip_and_convert(zip_path: Path, out_dir: Path) -> List[Path]:
    """
    Blocking heavy operations: extract zip and find pairs, merge images.
    Runs in thread via asyncio.to_thread, returns list of output file Paths.
    """
    # Extract zip
    extract_dir = out_dir / "extracted"
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(path=extract_dir)

    # Walk and collect png files
    files = []
    for p in extract_dir.rglob("*.png"):
        files.append(p)

    # map base -> {'rgb':path, 'sa':path}
    pairs_map: Dict[str, Dict[str, Path]] = {}
    for f in files:
        key = basename_key(f.name)
        if not key:
            continue
        base, kind = key
        pairs_map.setdefault(base, {})[kind] = f

    # create outputs
    outputs: List[Path] = []
    for base, dic in pairs_map.items():
        if "rgb" in dic and "sa" in dic:
            out_p = out_dir / f"{base}.png"
            try:
                merge_rgb_sa_blocking(dic["rgb"], dic["sa"], out_p)
                outputs.append(out_p)
            except Exception:
                # skip problematic pairs
                continue
    return outputs

async def _handle_zip_mode(chat_id: int, state: Dict[str, Any], zip_file_path: Path, update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Prepare working dir
    work_dir = Path(tempfile.mkdtemp(prefix="conv_zip_"))
    out_dir = work_dir / "out"
    out_dir.mkdir(parents=True, exist_ok=True)

    # progress message
    progress_msg = await update.message.reply_text("📦 Menerima ZIP... memulai ekstraksi & konversi.")
    progress_state = {
        "total": 0,
        "done": 0,
        "start_time": time.time(),
        "finished": False,
    }

    # run extract & convert in thread (blocking)
    try:
        outputs = await asyncio.to_thread(_process_zip_and_convert, zip_file_path, out_dir)
    except Exception as e:
        await edit_progress_safe(progress_msg, f"❌ Gagal proses ZIP: {e}")
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        _states.pop(chat_id, None)
        return

    total = len(outputs)
    progress_state["total"] = total

    if total == 0:
        await edit_progress_safe(progress_msg, "⚠️ Tidak ada pasangan *_rgb.png & *_sa.png ditemukan di ZIP.")
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass
        _states.pop(chat_id, None)
        return

    # send outputs one-by-one, editing progress message
    for idx, out_file in enumerate(outputs, start=1):
        progress_state["done"] = idx - 1
        text = f"📦 Mengonversi ZIP — Proses: {build_bar(idx-1, total)}\n⏱️ Elapsed: {int(time.time()-progress_state['start_time'])}s\n🔁 Mengirim {out_file.name} ({idx}/{total})..."
        await edit_progress_safe(progress_msg, text)
        try:
            size = out_file.stat().st_size
            if size <= TELEGRAM_MAX_FILE_BYTES:
                # send (await)
                with open(out_file, "rb") as fh:
                    await context.bot.send_document(chat_id=chat_id, document=fh, filename=out_file.name)
            else:
                # fallback
                link = await asyncio.to_thread(upload_to_transfersh, out_file)
                if link:
                    await context.bot.send_message(chat_id=chat_id, text=f"🔗 {out_file.name}: {link}")
                else:
                    await context.bot.send_message(chat_id=chat_id, text=f"❌ Gagal kirim {out_file.name} (terlalu besar).")
        except Exception as e:
            await context.bot.send_message(chat_id=chat_id, text=f"⚠️ Gagal kirim {out_file.name}: {e}")
        # cleanup single output if desired (keep for zip removal)
        try:
            out_file.unlink(missing_ok=True)
        except Exception:
            pass

    # final edit + cleanup
    await edit_progress_safe(progress_msg, "✅ Semua selesai. Semua file telah dikirim.")
    try:
        shutil.rmtree(work_dir)
        zip_file_path.unlink(missing_ok=True)
    except Exception:
        pass
    _states.pop(chat_id, None)

# ---------- message handler ----------
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    state = _states.get(chat_id)
    if not state:
        return

    text = (update.message.text or "").strip().lower()

    # cancel shortcuts
    if text in ("batal", "cancel", "stop"):
        _states.pop(chat_id, None)
        await update.message.reply_text("❌ Proses dibatalkan.")
        return

    mode = state.get("mode")

    # ---------- FILE MODE ----------
    if mode == "await_files":
        # Expect document file
        doc = update.message.document
        if not doc:
            await update.message.reply_text("⚠️ Kirim file sebagai **Document** (bukan photo).")
            return
        # store into temp dir
        work = Path(tempfile.mkdtemp(prefix="conv_files_"))
        dest = work / doc.file_name
        file_obj = await context.bot.get_file(doc.file_id)
        try:
            await _download_telegram_file(file_obj, dest)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Gagal download file: {e}")
            shutil.rmtree(work, ignore_errors=True)
            _states.pop(chat_id, None)
            return
        state.setdefault("files_meta", []).append({"name": doc.file_name, "path": str(dest)})
        # if we have 2 files, process
        if len(state.get("files_meta", [])) >= 2:
            await _handle_file_mode(chat_id, state, update, context)
        else:
            await update.message.reply_text("✅ File diterima. Silakan kirim file kedua.")
        return

    # ---------- ZIP MODE ----------
    if mode == "await_zip":
        doc = update.message.document
        if not doc:
            await update.message.reply_text("⚠️ Kirim file .zip sebagai Document.")
            return
        if not doc.file_name.lower().endswith(".zip"):
            await update.message.reply_text("⚠️ File bukan .zip. Silakan kirim file ZIP.")
            return

        work = Path(tempfile.mkdtemp(prefix="conv_ziprecv_"))
        dest = work / doc.file_name
        file_obj = await context.bot.get_file(doc.file_id)
        try:
            await _download_telegram_file(file_obj, dest)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Gagal download ZIP: {e}")
            shutil.rmtree(work, ignore_errors=True)
            _states.pop(chat_id, None)
            return

        # kick off processing in background
        asyncio.create_task(_handle_zip_mode(chat_id, state, dest, update, context))
        await update.message.reply_text("📥 ZIP diterima — mulai proses ekstraksi & konversi. Silakan tunggu...")
        return

    # other modes or unknown
    await update.message.reply_text("⚠️ Flow tidak dikenali. Gunakan /cmdconvert untuk mulai.")

# ---------- register ----------
def register_convert(app):
    app.add_handler(CommandHandler("cmdconvert", cmdconvert))
    app.add_handler(CommandHandler("helpconvert", helpconvert))
    # pattern ^conv_ so callback button presses with conv_* are routed here
    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^conv_"))
    # accept documents (PNG or ZIP) as messages to this feature
    app.add_handler(MessageHandler(filters.Document.ALL & ~filters.COMMAND, message_handler))